/**
 * http://usejsdoc.org/
 */
// app은 서버

const app = require('express')(); 
// express: 외부모듈이며 http 모듈에 여러 기능을 추가해서 쉽게 사용할 수 있게 만든 모듈
const http = require('http').createServer(app); // app형식
const io = require('socket.io')(http); // http형식
const ip = require('ip');
const reqip = require('request-ip');
app.get('/', (req, res) => { 
// req: 요청받은것 res: 응답해준것
  res.sendFile(__dirname + '/index.html');// app.js가 있는 경로 + /index.html
  console.log(reqip.getClientIp(req));
});
io.on('connection', (socket) => {
	
  console.log('님이 채팅방에 참여했습니다.');
  socket.on('chat message', (msg) => {
    io.emit('chat message', msg);
  });
  socket.on('disconnect', () => {
  console.log('님이 채팅방에 퇴장했습니다.');
  });
});
http.listen(3000, () => {
  console.log('Connected at 3000');
});