const os = require('os');
const https = require('https');
const socketIO = require('socket.io');
const nodeStatic = require('node-static');
const fs = require('fs');
var options = {

		//key : fs.readFileSync('test/key.pem'),
		//cert : fs.readFileSync('test/cert.pem')
			
		//인증서 불러옴
		key : fs.readFileSync('test/private.key.pem'),
		cert : fs.readFileSync('test/mycommoncrt.crt')

	};
let fileServer = new(nodeStatic.Server)();
let app = https.createServer(options,(req,res)=>{
    fileServer.serve(req,res);
}).listen(3000);

let io = socketIO.listen(app);
io.sockets.on('connection',socket=>{
    function log() {
        let array = ['Message from server:'];
        array.push.apply(array,arguments);
        socket.emit('log',array);
    }

    socket.on('message',message=>{
        log('Client said : ' ,message);
        socket.broadcast.emit('message',message);
    });

    socket.on('create or join',room=>{
        let clientsInRoom = io.sockets.adapter.rooms[room];
        let numClients = clientsInRoom ? Object.keys(clientsInRoom.sockets).length : 0;
        log('Room ' + room + ' now has ' + numClients + ' client(s)');
        
        if(numClients === 0){
            console.log('create room!');
            socket.join(room);
            log('Client ID ' + socket.id + ' created room ' + room);
            socket.emit('created',room,socket.id);
        }
        else if(numClients===1){
            console.log('join room!');
            log('Client Id' + socket.id + 'joined room' + room);
            io.sockets.in(room).emit('join',room);
            socket.join(room);
            socket.emit('joined',room,socket.id);
            io.sockets.in(room).emit('ready');
        }else{
            socket.emit('full',room);
        }
    });


});
