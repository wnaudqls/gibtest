var http = require('http');
var io = require('socket.io');
var port = 3000;

// Start the server at port 3000
var server = http.createServer(function(req, res){ 
    // Send HTML headers and message
    res.writeHead(200,{ 'Content-Type': 'text/html' }); 
    res.end('<h1>Hello Socket Lover!</h1>');
});

server.listen(port);

// Create a Socket.IO instance, passing it our server
var socket = io.listen(server);

// 클라이언트 접속했을때
socket.on('connection', function(client){ 
    console.log('클라이언트의 접속이 감지되었습니다.');	
    socket.emit('message', '\n관리자: 서버에 오신걸 환영합니다.');
   
    // 클라이언트에게 message 이벤트롤 보냄
    client.on('message',function(event){ 
        console.log('클라이언트로부터 메세지를 받았습니다!',event);
    });

    client.on('disconnect',function(){
        //clearInterval(interval);
        console.log('Server has disconnected');
    });
});


console.log('Server running at http://127.0.0.1:' + port + '/');