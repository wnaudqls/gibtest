/**
 * http://usejsdoc.org/
 */

let localVideo = document.getElementById("localVideo");
let remoteVideo = document.getElementById("remoteVideo");
let localStream;
let socket = io.connect();
let isInitiator = false;
navigator.mediaDevices
	//디바이스 설정 및 잡는 역할
	.getUserMedia({
		video: true,
		audio: false,
	})
	.then(gotStream)

	.catch((error) => console.error(error));
	//error를 잡은경우, console에 띄움
function gotStream(stream) {
	console.log("로컬 스트림을 추가합니다.");
	//stream 화면 추가하는 로그
	localStream = stream;
	localVideo.srcObject = stream;
	sendMessage("미디어 객체를 감지하였습니다.");
	//캠을 인식하면, 메세지 띄움
	if(isInitiator){
		maybeStart();
	}
}
function sendMessage(message) {
	console.log('클라이언트에게 보내는 메세지: ', message);
	//클라이언트에게 보내는 메세지(콘솔로그에 띄움)

	socket.emit('message', message);
} 
function createPeerConnection() {
	try{
		pc = new RTCPeerConnection(null);
		//RTCPeerConnction 객체 선언
		pc.onicecandidate = handleIceCandidate;
		pc.onaddstream = handleRemoteStreamAdded;
		console.log("RTCPeerConnection 객체를 생성했습니다.");
		
	}catch (e) {
		alert("RTCPeerConnection 객체를 만들수 없습니다.");
		return;
	}
}
function handleIceCandidate(event) {
	console.log("iceCandidateEvent",event);
	if(event.candidate){
		//candidate 이벤트가 발생시
		sendMessage({
			//message 설정 (key: value)
			type: "candidate",
			label: event.candidate.sdpMLineIndex,
			id: event.candidate.sdpMid,
			candidate: event.candidate.candidate,
		});
	}else{
		console.log("candidates 이벤트가 끝낫습니다.");
	}
}
function handleCreateOfferError(event) {
	console.log("createOffer() error: ", event);
}
function handleRemoteStreamAdded(event){
	console.log("remote stream 추가했읍니다.");
	remoteStream = event.stream;
	//방송 추가설정
	remoteVideo.srcObject = remoteStream;
	//srcObject
}
function maybeStart() {
	console.log(">>MaybeStart() : ", isStarted, localStream, isChannelReady);
	if(!isStarted && typeof localStream !== "undefined" && isChannelReady){
		//아직 시작하지 않고 localStream이 확인된 상태에서 준비된 경우
		console.log(">>>>> peer connection 생성하는중");
		createPeerConnection();
		pc.addStream(localStream);
		isStarted = true;
		console.log("isInitiator : " + isInitiator);
		if(isInitiator){
			doCall();
		}
	}else{
		console.error('maybeStart를 시작할 수 없습니다!');
	}
}
function doCall() {
	console.log("Sending offer to peer");
	//클라이언트에게 요청을 보내는중
}
function doAnswer(){
	console.log("Sending answer to peer");
	//클라이언트에게 답을 보내는중
	pc.createAnswer().then(
		setLocalAndSendMessage,
		onCreateSessionDescriptionError
	);
}
function setLocalAndMessage(sessionDescription) {
	pc.setLocalDescription(sessionDescription);
	sendMessage(sessionDescription);
}


