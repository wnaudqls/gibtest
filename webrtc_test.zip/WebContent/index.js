var app = require('express')();
var https = require('https');
var socketio = require('socket.io')(https);
const nodeStatic = require('node-static');
var fs = require('fs');
var options = {
		key : fs.readFileSync('test/private.key.pem'),
		cert : fs.readFileSync('test/mycommoncrt.crt')
};

let fileServer = new(nodeStatic.Server)();

let server = https.createServer(options, (req,res)=>{
    fileServer.serve(req,res);
 
}).listen(3000);

let io = socketio.listen(server);

app.get('/', function (req, res) {
    res.send('<h1>안녕하세요 "/" 경로 입니다.</h1>');
});

io.sockets.on('connection', function (socket) {
 
    
  
    socket.on('client_disconn', function(name) {
    	io.emit('client_disconn', name);
	});
    socket.on('client_conn', function(name) {
    	console.log(name + "님이 접속하셧습니다." );
    	 io.emit('client_conn', name);
	})
    
    socket.on('disconnect', function (error, name) {
    	io.emit('client_disconn', error, name);
        console.log('한명의 유저가 접속해제를 했습니다.');
        
    });

    socket.on('send_msg', function (msg, name) {
        //콘솔로 출력을 한다.
        console.log(name + ": " + msg);
        //다시, 소켓을 통해 이벤트를 전송한다.
        io.emit('send_msg', msg, name);
    });
});
 



